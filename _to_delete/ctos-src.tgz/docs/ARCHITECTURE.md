# Creative Touch Website OS — Architecture Baseline

Internal AI-assisted website production control plane.
Origin: Lovable (architecture + data layer complete, UI unfinished). Reconstructed locally.

## Stack
TypeScript · React 19 · TanStack Router / TanStack Start · Vite · Tailwind CSS 4 · shadcn/Radix UI · Lucide React · class-variance-authority · React Hook Form · Zod

No Supabase / auth / API integrations yet. State is an intentional in-memory repository
(`src/state/os-store.tsx`) so the UI can migrate to Supabase later without rewriting components.

## Files to be reconstructed from Lovable (pending source)
- src/data/types.ts
- src/data/seed.ts
- src/state/os-store.tsx
- src/components/os/AppSidebar.tsx
- src/components/os/PageHeader.tsx
- src/components/os/status.tsx

## Core entities
Project · Client · Agent · ProjectPage · Ticket · Artifact · QAItem · LaunchHold · Approval · ActivityEvent

## Project state machine
NEW → DISCOVERY → STRATEGY → DESIGN → CONTENT → READY_TO_BUILD → BUILDING → QA → READY_TO_LAUNCH → LIVE → MAINTENANCE → ARCHIVED

Backward transitions allowed: QA → BUILDING, READY_TO_LAUNCH → QA.

## Specialist agents
- ORCHESTRATOR
- 01 Research & Discovery
- 02 UX & Conversion Architect
- 03 Creative Director
- 04 SEO & Content Architect
- 05 WordPress / Elementor Builder
- 06 QA & Launch Auditor

## First seed project
U-Proof (waterproofing products, client Martin).

## Status
Skeleton only. Implementation waits for the continuation specification.
