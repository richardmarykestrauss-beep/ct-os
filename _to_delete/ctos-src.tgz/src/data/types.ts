/**
 * Creative Touch Website OS — core domain types.
 *
 * All entities use stable string IDs and explicit foreign-key-style references
 * so the in-memory repository can later be swapped for Supabase tables
 * without changing UI components.
 *
 * Dates: ISO strings. `null` means "unknown / not recorded" — never invent history.
 */

export type ISODate = string;

// ---------------------------------------------------------------------------
// Project state machine
// ---------------------------------------------------------------------------

export type ProjectState =
  | "NEW"
  | "DISCOVERY"
  | "STRATEGY"
  | "DESIGN"
  | "CONTENT"
  | "READY_TO_BUILD"
  | "BUILDING"
  | "QA"
  | "READY_TO_LAUNCH"
  | "LIVE"
  | "MAINTENANCE"
  | "ARCHIVED";

export type ProjectType =
  | "NEW_WEBSITE"
  | "WEBSITE_REBUILD"
  | "ECOMMERCE_BUILD"
  | "ECOMMERCE_REBUILD"
  | "MIGRATION"
  | "LANDING_PAGE"
  | "MAINTENANCE_ONBOARDING";

export type Platform = "WordPress" | "Elementor" | "Elementor Pro" | "WooCommerce" | "Other";

// ---------------------------------------------------------------------------
// Pipeline phases (production pipeline shown on dashboards)
// ---------------------------------------------------------------------------

export type PhaseKey = "DISCOVERY" | "UX" | "CREATIVE" | "CONTENT" | "BUILD" | "QA" | "LAUNCH";

export type PhaseStatus = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETE" | "PENDING_HOLDS" | "BLOCKED";

export interface ProjectPhase {
  id: string;
  projectId: string;
  key: PhaseKey;
  label: string;
  status: PhaseStatus;
  order: number;
  /** Optional free-text note e.g. "Pending launch holds" */
  note?: string;
}

// ---------------------------------------------------------------------------
// Entities
// ---------------------------------------------------------------------------

export interface Client {
  id: string;
  name: string;
  websiteUrl?: string;
  contactName?: string;
  contactEmail?: string;
  notes?: string;
  createdAt: ISODate | null;
}

export interface Project {
  id: string;
  clientId: string;
  name: string;
  type: ProjectType;
  platforms: Platform[];
  /** Human platform summary e.g. "WordPress + Elementor Pro + WooCommerce" */
  platformSummary: string;
  domain?: string;
  state: ProjectState;
  /** Human-readable operational status, e.g. "BUILD COMPLETE / HUMAN REVIEW" */
  statusLabel: string;
  /** 0–100 production progress (approximate, not mathematically precise). */
  progress: number;
  progressNote?: string;
  currentPhase: string;
  nextAction: string;
  primaryGoal?: string;
  hasExistingWebsite?: boolean;
  notes?: string;
  createdAt: ISODate | null;
  updatedAt: ISODate | null;
}

export type AgentCode = "ORCH" | "A01" | "A02" | "A03" | "A04" | "A05" | "A06";

export type AgentStatus = "IDLE" | "WORKING" | "WAITING_APPROVAL" | "BLOCKED";

export interface Agent {
  id: string;
  code: AgentCode;
  /** Display code e.g. "01", "ORCH" */
  shortCode: string;
  name: string;
  role: string;
  responsibilities: string[];
  status: AgentStatus;
  statusDetail?: string;
  currentProjectId?: string | null;
  currentTicketId?: string | null;
  lastRunAt: ISODate | null;
  outputsProduced: number;
}

export type PageType = "Page" | "Archive Template" | "Single Template" | "Utility" | "Legal" | "Solution";

export type BuildStatus = "QUEUED" | "BUILDING" | "COMPLETE" | "SUPERSEDED";

export type QAStatus = "NOT_RUN" | "IN_QA" | "PASS" | "FAIL";

export interface ProjectPage {
  id: string;
  projectId: string;
  title: string;
  type: PageType;
  buildStatus: BuildStatus;
  qaStatus: QAStatus;
  /** WordPress preview post ID or Elementor template ID */
  wpRefKind: "PREVIEW" | "TEMPLATE";
  wpRefId: number | null;
  /** Hold flag: linked launch hold or note (not a defect) */
  holdNote?: string;
  notes?: string;
  ticketId?: string;
  updatedAt: ISODate | null;
}

export type TicketStatus = "QUEUED" | "READY" | "BUILDING" | "REVIEW" | "COMPLETE" | "BLOCKED";

export type TicketPriority = "P0" | "P1" | "P2" | "P3";

export type TicketApprovalState = "NOT_REQUIRED" | "PENDING" | "APPROVED" | "NEEDS_REVISION";

export interface Ticket {
  id: string;
  /** Display code e.g. CT-UP-021 */
  code: string;
  projectId: string;
  title: string;
  agentId: string;
  phase: PhaseKey;
  status: TicketStatus;
  priority: TicketPriority;
  objective: string;
  environment: string;
  scope: string[];
  doNotChange: string[];
  executionOutput?: string;
  safetyCheck?: string;
  warnings: string[];
  approvalState: TicketApprovalState;
  order: number;
  createdAt: ISODate | null;
  updatedAt: ISODate | null;
  completedAt: ISODate | null;
}

export type ArtifactKind =
  | "PROJECT_BRIEF"
  | "DISCOVERY_REPORT"
  | "UX_PLAN"
  | "DESIGN_SYSTEM"
  | "CONTENT_MAP"
  | "BUILD_REPORT"
  | "QA_AUDIT"
  | "REGRESSION_AUDIT"
  | "OTHER";

export interface Artifact {
  id: string;
  projectId: string;
  kind: ArtifactKind;
  title: string;
  producedByAgentId?: string;
  ticketId?: string;
  /** For MVP these are metadata records; no file is claimed to exist unless storageRef is set. */
  storageRef: string | null;
  summary?: string;
  createdAt: ISODate | null;
}

export type QASeverity = "P0" | "P1" | "P2" | "P3";

export type QACategory =
  | "Responsive"
  | "Visual"
  | "Content"
  | "WooCommerce"
  | "SEO"
  | "Forms"
  | "Performance"
  | "Technical"
  | "Migration";

export type QAItemStatus = "OPEN" | "IN_PROGRESS" | "FIXED" | "VERIFIED" | "WONT_FIX";

export interface QAItem {
  id: string;
  projectId: string;
  pageId?: string;
  ticketId?: string;
  title: string;
  severity: QASeverity;
  category: QACategory;
  description: string;
  assignedAgentId?: string;
  status: QAItemStatus;
  createdAt: ISODate | null;
  resolvedAt: ISODate | null;
}

export type HoldOwner = "Creative Touch" | "Client" | "Client / Creative Touch";

export interface LaunchHold {
  id: string;
  projectId: string;
  pageId?: string;
  title: string;
  detail?: string;
  owner: HoldOwner;
  resolved: boolean;
  resolvedAt: ISODate | null;
  createdAt: ISODate | null;
}

export type ApprovalGate = "STRATEGY" | "DESIGN" | "STAGING_BUILD" | "LAUNCH";

export type ApprovalStatus = "PENDING" | "APPROVED" | "CHANGES_REQUESTED";

export interface Approval {
  id: string;
  projectId: string;
  gate: ApprovalGate;
  requestedBy: string;
  status: ApprovalStatus;
  notes?: string;
  decidedBy?: string;
  decidedAt: ISODate | null;
  createdAt: ISODate | null;
}

export type ActivityKind =
  | "PROJECT_CREATED"
  | "STATE_CHANGED"
  | "TICKET_CREATED"
  | "TICKET_STATUS"
  | "TICKET_COMPLETED"
  | "QA_RUN"
  | "QA_PASS"
  | "QA_FIX"
  | "APPROVAL"
  | "HOLD"
  | "AGENT"
  | "NOTE";

export interface ActivityEvent {
  id: string;
  projectId: string | null;
  kind: ActivityKind;
  /** Short reference (ticket code, gate name) shown as a chip */
  ref?: string;
  message: string;
  actor: string;
  /** null when historical timing is unknown — display by order, not date */
  at: ISODate | null;
  order: number;
}

// ---------------------------------------------------------------------------
// Aggregate store shape (what a repository returns)
// ---------------------------------------------------------------------------

export interface OSData {
  clients: Client[];
  projects: Project[];
  phases: ProjectPhase[];
  agents: Agent[];
  pages: ProjectPage[];
  tickets: Ticket[];
  artifacts: Artifact[];
  qaItems: QAItem[];
  launchHolds: LaunchHold[];
  approvals: Approval[];
  activity: ActivityEvent[];
}
