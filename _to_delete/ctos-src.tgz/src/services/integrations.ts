/**
 * Integration seams — control plane vs execution plane.
 *
 * The dashboard (control plane) records intent and state. External systems
 * (execution plane) do the actual work. None of these are connected in the MVP;
 * this file defines the shape so adapters can be dropped in later without UI rewrites.
 */

export type IntegrationStatus = "NOT_CONNECTED" | "FUTURE";

export interface IntegrationDescriptor {
  id: string;
  name: string;
  plane: "control" | "execution";
  purpose: string;
  status: IntegrationStatus;
}

export const INTEGRATIONS: IntegrationDescriptor[] = [
  { id: "supabase", name: "Supabase", plane: "control", purpose: "Persistence, auth and realtime for the OS store.", status: "NOT_CONNECTED" },
  { id: "orchestrator", name: "AI Orchestrator", plane: "execution", purpose: "Coordinates specialist agents and enforces approval gates.", status: "FUTURE" },
  { id: "claude-wp", name: "Claude / WordPress execution", plane: "execution", purpose: "Executes build tickets against staging via SSH + WP-CLI.", status: "FUTURE" },
  { id: "openai", name: "OpenAI", plane: "execution", purpose: "Alternate model provider for content and analysis agents.", status: "FUTURE" },
  { id: "gemini", name: "Gemini", plane: "execution", purpose: "Alternate model provider for research and image tasks.", status: "FUTURE" },
  { id: "wordpress-mcp", name: "WordPress MCP", plane: "execution", purpose: "Structured read/write access to WordPress sites.", status: "FUTURE" },
  { id: "google", name: "Google", plane: "execution", purpose: "Search Console, Analytics, Tag Manager, Business Profile.", status: "FUTURE" },
  { id: "meta", name: "Meta", plane: "execution", purpose: "Pixel, domain verification, business assets.", status: "FUTURE" },
  { id: "cloudflare", name: "Cloudflare", plane: "execution", purpose: "DNS, proxy and SSL for client zones.", status: "FUTURE" },
  { id: "hosting", name: "Hosting", plane: "execution", purpose: "Company-controlled host: staging, backups, SSH.", status: "FUTURE" },
];

/** Adapter contracts. Implementations arrive with credentials later — never in the MVP. */
export interface AgentRunner {
  runTicket(ticketId: string): Promise<{ output: string }>;
}
export interface SiteExecutor {
  openPreview(ref: { kind: "PREVIEW" | "TEMPLATE"; id: number }): Promise<string>;
}
