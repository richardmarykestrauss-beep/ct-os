/**
 * Repository seam.
 *
 * The UI never talks to a backend directly; it talks to the OS store, which
 * loads/saves through an OSRepository. Swapping InMemoryRepository for a
 * SupabaseRepository later should not require UI changes.
 */
import type { OSData } from "@/data/types";
import { seedData } from "@/data/seed";

export interface OSRepository {
  /** Load the full dataset (MVP: synchronous seed; Supabase: async fetch). */
  load(): Promise<OSData> | OSData;
  /** Persist a snapshot. In-memory implementation is a no-op. */
  persist(data: OSData): Promise<void> | void;
  readonly kind: "memory" | "supabase";
}

export class InMemoryRepository implements OSRepository {
  readonly kind = "memory" as const;
  private snapshot: OSData;
  constructor(initial: OSData = seedData) {
    // structuredClone so seed constants are never mutated.
    this.snapshot = structuredClone(initial);
  }
  load() {
    return this.snapshot;
  }
  persist(data: OSData) {
    this.snapshot = data;
  }
}

/** Placeholder to make the future seam explicit. Not implemented — no network calls in the MVP. */
export class SupabaseRepository implements OSRepository {
  readonly kind = "supabase" as const;
  load(): never {
    throw new Error("SupabaseRepository is a future integration — not connected.");
  }
  persist(): never {
    throw new Error("SupabaseRepository is a future integration — not connected.");
  }
}

export const defaultRepository: OSRepository = new InMemoryRepository();
