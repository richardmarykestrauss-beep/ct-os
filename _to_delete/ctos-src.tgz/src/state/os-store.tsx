/**
 * OS store — the single in-memory state repository the whole UI consumes.
 *
 * Design: React context + reducer over an `OSData` snapshot loaded from an
 * OSRepository. Every mutation is an action so a Supabase-backed repository can
 * later replay the same actions as writes. Components never hold domain data.
 */
import * as React from "react";
import type {
  ActivityEvent,
  ActivityKind,
  Agent,
  Approval,
  ApprovalStatus,
  Client,
  LaunchHold,
  OSData,
  Platform,
  Project,
  ProjectPage,
  ProjectPhase,
  ProjectState,
  ProjectType,
  QAItem,
  Ticket,
  TicketApprovalState,
  TicketStatus,
} from "@/data/types";
import { PHASES, PROJECT_STATE_LABELS, STATE_PROGRESS, canTransition } from "@/data/state-machine";
import { AGENT_IDS } from "@/data/seed";
import { defaultRepository, type OSRepository } from "@/services/repository";
import { newId, nowIso } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------

export interface NewProjectInput {
  clientName: string;
  websiteUrl?: string;
  type: ProjectType;
  primaryGoal: string;
  platforms: Platform[];
  hasExistingWebsite: boolean;
  notes?: string;
}

type Action =
  | { type: "CREATE_PROJECT"; input: NewProjectInput; ids: { clientId: string; projectId: string; ticketId: string } }
  | { type: "TRANSITION_PROJECT"; projectId: string; to: ProjectState }
  | { type: "SET_TICKET_STATUS"; ticketId: string; status: TicketStatus }
  | { type: "SET_TICKET_APPROVAL"; ticketId: string; approval: TicketApprovalState }
  | { type: "RUN_TICKET"; ticketId: string }
  | { type: "RUN_QA"; projectId: string; ticketId: string }
  | { type: "DECIDE_APPROVAL"; approvalId: string; status: ApprovalStatus; notes?: string }
  | { type: "TOGGLE_HOLD"; holdId: string }
  | { type: "SET_QA_ITEM_STATUS"; qaItemId: string; status: QAItem["status"] }
  | { type: "NOTE"; projectId: string | null; message: string };

const ACTOR = "Production Lead";

function pushActivity(data: OSData, projectId: string | null, kind: ActivityKind, message: string, ref?: string, actor = ACTOR): ActivityEvent[] {
  const order = data.activity.reduce((m, a) => Math.max(m, a.order), 0) + 1;
  return [...data.activity, { id: newId("act"), projectId, kind, ref, message, actor, at: nowIso(), order }];
}

function touchProject(projects: Project[], projectId: string, patch: Partial<Project> = {}): Project[] {
  return projects.map((p) => (p.id === projectId ? { ...p, ...patch, updatedAt: nowIso() } : p));
}

function reducer(data: OSData, action: Action): OSData {
  switch (action.type) {
    case "CREATE_PROJECT": {
      const { input, ids } = action;
      const now = nowIso();
      const client: Client = {
        id: ids.clientId,
        name: input.clientName,
        websiteUrl: input.websiteUrl || undefined,
        notes: input.notes,
        createdAt: now,
      };
      const platformSummary = input.platforms.length ? input.platforms.join(" + ") : "Platform TBC";
      const project: Project = {
        id: ids.projectId,
        clientId: ids.clientId,
        name: input.clientName,
        type: input.type,
        platforms: input.platforms,
        platformSummary,
        domain: input.websiteUrl || undefined,
        state: "DISCOVERY",
        statusLabel: "DISCOVERY IN PROGRESS",
        progress: STATE_PROGRESS.DISCOVERY,
        progressNote: "Approximate production progress.",
        currentPhase: "Research & Discovery",
        nextAction: "Run first discovery ticket",
        primaryGoal: input.primaryGoal,
        hasExistingWebsite: input.hasExistingWebsite,
        notes: input.notes,
        createdAt: now,
        updatedAt: now,
      };
      const phases: ProjectPhase[] = PHASES.map((p, i) => ({
        id: newId("ph"),
        projectId: project.id,
        key: p.key,
        label: p.label,
        status: i === 0 ? "IN_PROGRESS" : "NOT_STARTED",
        order: i + 1,
      }));
      const projectIndex = data.projects.length + 1;
      const code = `CT-P${projectIndex}-001`;
      const ticket: Ticket = {
        id: ids.ticketId,
        code,
        projectId: project.id,
        title: "Research & Discovery",
        agentId: AGENT_IDS.A01,
        phase: "DISCOVERY",
        status: "QUEUED",
        priority: "P2",
        objective: `Produce business, existing-site and competitor intelligence for ${input.clientName}. Primary goal: ${input.primaryGoal}`,
        environment: input.hasExistingWebsite && input.websiteUrl ? `Existing site — ${input.websiteUrl}` : "No existing website",
        scope: ["Business analysis", "Existing-site audit", "Competitor intelligence"],
        doNotChange: ["Any live site", "DNS / nameservers", "Payment credentials"],
        warnings: [],
        approvalState: "NOT_REQUIRED",
        order: 1,
        createdAt: now,
        updatedAt: now,
        completedAt: null,
      };
      let next: OSData = {
        ...data,
        clients: [...data.clients, client],
        projects: [...data.projects, project],
        phases: [...data.phases, ...phases],
        tickets: [...data.tickets, ticket],
        approvals: [
          ...data.approvals,
          { id: newId("appr"), projectId: project.id, gate: "STRATEGY", requestedBy: "Orchestrator", status: "PENDING", decidedAt: null, createdAt: now },
        ],
        artifacts: [
          ...data.artifacts,
          { id: newId("art"), projectId: project.id, kind: "PROJECT_BRIEF", title: "Project Brief", producedByAgentId: AGENT_IDS.ORCH, storageRef: null, summary: input.primaryGoal, createdAt: now },
        ],
      };
      next = { ...next, activity: pushActivity(next, project.id, "PROJECT_CREATED", `Project created — ${project.name} (${platformSummary})`) };
      next = { ...next, activity: pushActivity(next, project.id, "TICKET_CREATED", `${code} created — Research & Discovery`, code, "Orchestrator") };
      return next;
    }

    case "TRANSITION_PROJECT": {
      const project = data.projects.find((p) => p.id === action.projectId);
      if (!project || !canTransition(project.state, action.to)) return data;
      const progress = action.to === "READY_TO_LAUNCH" || action.to === "QA" ? Math.max(project.progress, STATE_PROGRESS[action.to]) : STATE_PROGRESS[action.to];
      const projects = touchProject(data.projects, project.id, {
        state: action.to,
        statusLabel: PROJECT_STATE_LABELS[action.to].toUpperCase(),
        progress,
      });
      const next = { ...data, projects };
      return { ...next, activity: pushActivity(next, project.id, "STATE_CHANGED", `State changed ${PROJECT_STATE_LABELS[project.state]} → ${PROJECT_STATE_LABELS[action.to]}`) };
    }

    case "SET_TICKET_STATUS": {
      const ticket = data.tickets.find((t) => t.id === action.ticketId);
      if (!ticket || ticket.status === action.status) return data;
      const now = nowIso();
      const tickets = data.tickets.map((t) =>
        t.id === ticket.id ? { ...t, status: action.status, updatedAt: now, completedAt: action.status === "COMPLETE" ? now : t.completedAt } : t,
      );
      let next: OSData = { ...data, tickets, projects: touchProject(data.projects, ticket.projectId) };
      // Keep agent status coherent with ticket status.
      next = { ...next, agents: syncAgent(next, ticket.agentId, ticket.id, action.status) };
      const kind: ActivityKind = action.status === "COMPLETE" ? "TICKET_COMPLETED" : "TICKET_STATUS";
      return { ...next, activity: pushActivity(next, ticket.projectId, kind, `${ticket.code} → ${action.status === "COMPLETE" ? "completed" : action.status.toLowerCase()} — ${ticket.title}`, ticket.code) };
    }

    case "SET_TICKET_APPROVAL": {
      const ticket = data.tickets.find((t) => t.id === action.ticketId);
      if (!ticket) return data;
      const now = nowIso();
      const tickets = data.tickets.map((t) =>
        t.id === ticket.id
          ? {
              ...t,
              approvalState: action.approval,
              status: action.approval === "APPROVED" ? ("COMPLETE" as TicketStatus) : action.approval === "NEEDS_REVISION" ? ("BUILDING" as TicketStatus) : t.status,
              updatedAt: now,
              completedAt: action.approval === "APPROVED" ? now : t.completedAt,
            }
          : t,
      );
      let next: OSData = { ...data, tickets, projects: touchProject(data.projects, ticket.projectId) };
      next = { ...next, agents: syncAgent(next, ticket.agentId, ticket.id, action.approval === "APPROVED" ? "COMPLETE" : action.approval === "NEEDS_REVISION" ? "BUILDING" : ticket.status) };
      const msg = action.approval === "APPROVED" ? "approved" : action.approval === "NEEDS_REVISION" ? "sent back — needs revision" : "awaiting approval";
      return { ...next, activity: pushActivity(next, ticket.projectId, "APPROVAL", `${ticket.code} ${msg} — ${ticket.title}`, ticket.code) };
    }

    case "RUN_TICKET": {
      // Mock execution: the ticket moves to REVIEW with a placeholder output and the agent waits for approval.
      const ticket = data.tickets.find((t) => t.id === action.ticketId);
      if (!ticket) return data;
      const now = nowIso();
      const tickets = data.tickets.map((t) =>
        t.id === ticket.id
          ? {
              ...t,
              status: "REVIEW" as TicketStatus,
              approvalState: "PENDING" as TicketApprovalState,
              executionOutput:
                "[Local mock run] No AI execution plane is connected. This ticket was moved to Review so the approval flow can be exercised. Real execution will arrive via the AI Orchestrator seam.",
              safetyCheck: "Mock run — no external systems touched.",
              updatedAt: now,
            }
          : t,
      );
      let next: OSData = { ...data, tickets, projects: touchProject(data.projects, ticket.projectId, { nextAction: `Review ${ticket.code} output` }) };
      next = { ...next, agents: syncAgent(next, ticket.agentId, ticket.id, "REVIEW") };
      next = { ...next, activity: pushActivity(next, ticket.projectId, "AGENT", `${ticket.code} run (mock) — output ready for review`, ticket.code, "Orchestrator") };
      return next;
    }

    case "RUN_QA": {
      const project = data.projects.find((p) => p.id === action.projectId);
      if (!project) return data;
      const now = nowIso();
      const open = data.qaItems.filter((q) => q.projectId === project.id && (q.status === "OPEN" || q.status === "IN_PROGRESS")).length;
      const seq = data.tickets.filter((t) => t.projectId === project.id).length + 1;
      const prefix = project.id === "proj_uproof" ? "CT-UP" : `CT-P${data.projects.findIndex((p) => p.id === project.id) + 1}`;
      const code = `${prefix}-${String(seq).padStart(3, "0")}`;
      const ticket: Ticket = {
        id: action.ticketId,
        code,
        projectId: project.id,
        title: "QA Run (local)",
        agentId: AGENT_IDS.A06,
        phase: "QA",
        status: "COMPLETE",
        priority: "P2",
        objective: "Re-run QA across the current build state.",
        environment: "Staging",
        scope: ["All tracked pages"],
        doNotChange: ["Live production site"],
        executionOutput: `[Local mock run] QA re-run recorded. Open defects in store: ${open}. No real audit was executed — the QA & Launch Auditor execution plane is not connected.`,
        safetyCheck: "Mock run — read-only.",
        warnings: [],
        approvalState: "NOT_REQUIRED",
        order: seq,
        createdAt: now,
        updatedAt: now,
        completedAt: now,
      };
      let next: OSData = { ...data, tickets: [...data.tickets, ticket], projects: touchProject(data.projects, project.id) };
      next = { ...next, agents: next.agents.map((a) => (a.id === AGENT_IDS.A06 ? { ...a, lastRunAt: now, outputsProduced: a.outputsProduced + 1, currentProjectId: project.id, currentTicketId: null, status: "IDLE" } : a)) };
      next = { ...next, activity: pushActivity(next, project.id, "QA_RUN", `${code} QA run (mock) — ${open} open defect${open === 1 ? "" : "s"}`, code, "06 QA Auditor") };
      return next;
    }

    case "DECIDE_APPROVAL": {
      const approval = data.approvals.find((a) => a.id === action.approvalId);
      if (!approval) return data;
      const now = nowIso();
      const approvals = data.approvals.map((a) =>
        a.id === approval.id ? { ...a, status: action.status, notes: action.notes ?? a.notes, decidedBy: action.status === "PENDING" ? undefined : ACTOR, decidedAt: action.status === "PENDING" ? null : now } : a,
      );
      let next: OSData = { ...data, approvals, projects: touchProject(data.projects, approval.projectId) };
      if (approval.gate === "LAUNCH") {
        const orchStatus: Agent["status"] = action.status === "APPROVED" ? "IDLE" : action.status === "CHANGES_REQUESTED" ? "BLOCKED" : "WAITING_APPROVAL";
        next = { ...next, agents: next.agents.map((a) => (a.id === AGENT_IDS.ORCH ? { ...a, status: orchStatus, statusDetail: action.status === "APPROVED" ? "Launch approved" : action.status === "CHANGES_REQUESTED" ? "Launch changes requested" : "Human Review" } : a)) };
      }
      const label = action.status === "APPROVED" ? "approved" : action.status === "CHANGES_REQUESTED" ? "changes requested" : "reset to pending";
      return { ...next, activity: pushActivity(next, approval.projectId, "APPROVAL", `${approval.gate.replace("_", " ")} gate ${label}`, approval.gate) };
    }

    case "TOGGLE_HOLD": {
      const hold = data.launchHolds.find((h) => h.id === action.holdId);
      if (!hold) return data;
      const resolved = !hold.resolved;
      const now = nowIso();
      const launchHolds: LaunchHold[] = data.launchHolds.map((h) => (h.id === hold.id ? { ...h, resolved, resolvedAt: resolved ? now : null } : h));
      // Keep page hold notes coherent.
      const pages: ProjectPage[] = data.pages.map((p) => {
        if (!hold.pageId || p.id !== hold.pageId) return p;
        const stillHeld = launchHolds.some((h) => h.pageId === p.id && !h.resolved);
        return { ...p, holdNote: stillHeld ? p.holdNote : undefined, updatedAt: now };
      });
      const next: OSData = { ...data, launchHolds, pages, projects: touchProject(data.projects, hold.projectId) };
      return { ...next, activity: pushActivity(next, hold.projectId, "HOLD", `Launch hold ${resolved ? "resolved" : "reopened"} — ${hold.title}`) };
    }

    case "SET_QA_ITEM_STATUS": {
      const item = data.qaItems.find((q) => q.id === action.qaItemId);
      if (!item) return data;
      const now = nowIso();
      const qaItems = data.qaItems.map((q) => (q.id === item.id ? { ...q, status: action.status, resolvedAt: action.status === "FIXED" || action.status === "VERIFIED" ? now : null } : q));
      const next: OSData = { ...data, qaItems, projects: touchProject(data.projects, item.projectId) };
      return { ...next, activity: pushActivity(next, item.projectId, "QA_FIX", `QA item ${action.status.toLowerCase()} — ${item.title}`) };
    }

    case "NOTE": {
      return { ...data, activity: pushActivity(data, action.projectId, "NOTE", action.message) };
    }
  }
}

/** Reflect a ticket status change onto its agent so the Agents screen stays truthful. */
function syncAgent(data: OSData, agentId: string, ticketId: string, ticketStatus: TicketStatus): Agent[] {
  const ticket = data.tickets.find((t) => t.id === ticketId);
  return data.agents.map((a) => {
    if (a.id !== agentId) return a;
    const now = nowIso();
    switch (ticketStatus) {
      case "BUILDING":
        return { ...a, status: "WORKING", statusDetail: undefined, currentProjectId: ticket?.projectId ?? a.currentProjectId, currentTicketId: ticketId, lastRunAt: now };
      case "REVIEW":
        return { ...a, status: "WAITING_APPROVAL", statusDetail: "Output review", currentProjectId: ticket?.projectId ?? a.currentProjectId, currentTicketId: ticketId, lastRunAt: now, outputsProduced: a.outputsProduced + 1 };
      case "BLOCKED":
        return { ...a, status: "BLOCKED", statusDetail: "Ticket blocked", currentProjectId: ticket?.projectId ?? a.currentProjectId, currentTicketId: ticketId };
      case "COMPLETE":
      case "QUEUED":
      case "READY":
        return a.currentTicketId === ticketId ? { ...a, status: "IDLE", statusDetail: undefined, currentTicketId: null } : a;
    }
  });
}

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------

interface OSStoreValue {
  data: OSData;
  repositoryKind: OSRepository["kind"];
  actions: {
    createProject: (input: NewProjectInput) => { projectId: string; clientId: string };
    transitionProject: (projectId: string, to: ProjectState) => void;
    setTicketStatus: (ticketId: string, status: TicketStatus) => void;
    setTicketApproval: (ticketId: string, approval: TicketApprovalState) => void;
    runTicket: (ticketId: string) => void;
    runQA: (projectId: string) => void;
    decideApproval: (approvalId: string, status: ApprovalStatus, notes?: string) => void;
    toggleHold: (holdId: string) => void;
    setQAItemStatus: (qaItemId: string, status: QAItem["status"]) => void;
    note: (projectId: string | null, message: string) => void;
  };
}

const OSStoreContext = React.createContext<OSStoreValue | null>(null);

export function OSStoreProvider({ children, repository = defaultRepository }: { children: React.ReactNode; repository?: OSRepository }) {
  const initial = React.useMemo(() => {
    const loaded = repository.load();
    if (loaded instanceof Promise) throw new Error("Async repositories are not supported by the MVP provider yet.");
    return loaded;
  }, [repository]);

  const [data, dispatch] = React.useReducer(reducer, initial);

  React.useEffect(() => {
    void repository.persist(data);
  }, [data, repository]);

  const actions = React.useMemo<OSStoreValue["actions"]>(
    () => ({
      createProject: (input) => {
        const ids = { clientId: newId("client"), projectId: newId("proj"), ticketId: newId("t") };
        dispatch({ type: "CREATE_PROJECT", input, ids });
        return { projectId: ids.projectId, clientId: ids.clientId };
      },
      transitionProject: (projectId, to) => dispatch({ type: "TRANSITION_PROJECT", projectId, to }),
      setTicketStatus: (ticketId, status) => dispatch({ type: "SET_TICKET_STATUS", ticketId, status }),
      setTicketApproval: (ticketId, approval) => dispatch({ type: "SET_TICKET_APPROVAL", ticketId, approval }),
      runTicket: (ticketId) => dispatch({ type: "RUN_TICKET", ticketId }),
      runQA: (projectId) => dispatch({ type: "RUN_QA", projectId, ticketId: newId("t") }),
      decideApproval: (approvalId, status, notes) => dispatch({ type: "DECIDE_APPROVAL", approvalId, status, notes }),
      toggleHold: (holdId) => dispatch({ type: "TOGGLE_HOLD", holdId }),
      setQAItemStatus: (qaItemId, status) => dispatch({ type: "SET_QA_ITEM_STATUS", qaItemId, status }),
      note: (projectId, message) => dispatch({ type: "NOTE", projectId, message }),
    }),
    [],
  );

  const value = React.useMemo(() => ({ data, actions, repositoryKind: repository.kind }), [data, actions, repository.kind]);
  return <OSStoreContext.Provider value={value}>{children}</OSStoreContext.Provider>;
}

export function useOS(): OSStoreValue {
  const ctx = React.useContext(OSStoreContext);
  if (!ctx) throw new Error("useOS must be used inside <OSStoreProvider>");
  return ctx;
}

// ---------------------------------------------------------------------------
// Selectors (derived views — keep components free of data logic)
// ---------------------------------------------------------------------------

export function useProject(projectId: string) {
  const { data } = useOS();
  return React.useMemo(() => {
    const project = data.projects.find((p) => p.id === projectId) ?? null;
    if (!project) return null;
    const byOrder = (a: { order: number }, b: { order: number }) => a.order - b.order;
    const tickets = data.tickets.filter((t) => t.projectId === projectId).sort(byOrder);
    return {
      project,
      client: data.clients.find((c) => c.id === project.clientId) ?? null,
      phases: data.phases.filter((p) => p.projectId === projectId).sort(byOrder),
      pages: data.pages.filter((p) => p.projectId === projectId),
      tickets,
      artifacts: data.artifacts.filter((a) => a.projectId === projectId),
      qaItems: data.qaItems.filter((q) => q.projectId === projectId),
      launchHolds: data.launchHolds.filter((h) => h.projectId === projectId),
      approvals: data.approvals.filter((a) => a.projectId === projectId),
      activity: data.activity.filter((a) => a.projectId === projectId).sort((a, b) => b.order - a.order),
      currentTicket: tickets.find((t) => t.status === "BUILDING" || t.status === "REVIEW") ?? null,
      lastCompletedTicket: [...tickets].reverse().find((t) => t.status === "COMPLETE") ?? null,
      nextTicket: tickets.find((t) => t.status === "QUEUED" || t.status === "READY") ?? null,
    };
  }, [data, projectId]);
}

export function useDashboardStats() {
  const { data } = useOS();
  return React.useMemo(() => {
    const active = data.projects.filter((p) => p.state !== "ARCHIVED" && p.state !== "LIVE" && p.state !== "MAINTENANCE");
    return {
      activeProjects: active.length,
      inBuild: data.projects.filter((p) => p.state === "BUILDING" || p.state === "READY_TO_BUILD").length,
      awaitingApproval: data.approvals.filter((a) => a.status === "PENDING").length + data.tickets.filter((t) => t.approvalState === "PENDING").length,
      qaIssues: data.qaItems.filter((q) => q.status === "OPEN" || q.status === "IN_PROGRESS").length,
      readyToLaunch: data.projects.filter((p) => p.state === "READY_TO_LAUNCH").length,
    };
  }, [data]);
}

export function qaSeverityCounts(items: QAItem[]) {
  const open = items.filter((q) => q.status === "OPEN" || q.status === "IN_PROGRESS");
  return {
    P0: open.filter((q) => q.severity === "P0").length,
    P1: open.filter((q) => q.severity === "P1").length,
    P2: open.filter((q) => q.severity === "P2").length,
    P3: open.filter((q) => q.severity === "P3").length,
    total: open.length,
  };
}

export function agentById(data: OSData, id?: string | null) {
  return id ? (data.agents.find((a) => a.id === id) ?? null) : null;
}

export function pendingLaunchApproval(approvals: Approval[]) {
  return approvals.find((a) => a.gate === "LAUNCH" && a.status === "PENDING") ?? null;
}
