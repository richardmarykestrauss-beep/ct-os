import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/os/PageHeader";
import { AgentStatusBadge } from "@/components/os/status";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useOS } from "@/state/os-store";
import { cn, formatRelative } from "@/lib/utils";
import type { AgentStatus } from "@/data/types";
import { Bot, Crown } from "lucide-react";

export const Route = createFileRoute("/agents")({ component: AgentsPage });

const RING: Record<AgentStatus, string> = {
  IDLE: "border-border",
  WORKING: "border-accent shadow-[0_0_0_3px_var(--color-accent-soft)]",
  WAITING_APPROVAL: "border-warn shadow-[0_0_0_3px_var(--color-warn-soft)]",
  BLOCKED: "border-danger shadow-[0_0_0_3px_var(--color-danger-soft)]",
};

function AgentsPage() {
  const { data } = useOS();
  const counts = data.agents.reduce<Record<AgentStatus, number>>(
    (acc, a) => ({ ...acc, [a.status]: acc[a.status] + 1 }),
    { IDLE: 0, WORKING: 0, WAITING_APPROVAL: 0, BLOCKED: 0 },
  );
  return (
    <>
      <PageHeader
        title="Agents"
        subtitle="Specialist agents coordinated by the Orchestrator. Execution plane not connected — statuses reflect store state."
        meta={(Object.keys(counts) as AgentStatus[]).map((s) => (
          <span key={s} className="text-xs text-muted">
            <AgentStatusBadge status={s} /> <span className="num ml-1 font-medium text-ink">{counts[s]}</span>
          </span>
        ))}
      />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {data.agents.map((a) => {
          const project = a.currentProjectId ? data.projects.find((p) => p.id === a.currentProjectId) : null;
          const ticket = a.currentTicketId ? data.tickets.find((t) => t.id === a.currentTicketId) : null;
          const isOrch = a.code === "ORCH";
          return (
            <Card key={a.id} className={cn("border-2", RING[a.status], isOrch && "md:col-span-2 xl:col-span-3")}>
              <CardHeader className="flex-wrap items-center">
                <div className="flex items-center gap-3">
                  <div className={cn("flex size-9 items-center justify-center rounded-md font-mono text-xs font-bold", isOrch ? "bg-ink text-white" : "bg-neutral-soft text-ink-2")}>
                    {isOrch ? <Crown className="size-4" /> : a.shortCode}
                  </div>
                  <div>
                    <div className="text-[14px] font-semibold text-ink">{a.name}</div>
                    <div className="text-xs text-muted">{a.role}</div>
                  </div>
                </div>
                <AgentStatusBadge status={a.status} detail={a.statusDetail} />
              </CardHeader>
              <CardContent className={cn("grid grid-cols-2 gap-3 text-xs", isOrch && "md:grid-cols-4")}>
                <Field label="Current project">
                  {project ? (
                    <Link to="/projects/$projectId" params={{ projectId: project.id }} className="text-accent hover:underline">
                      {project.name}
                    </Link>
                  ) : (
                    <span className="text-faint">—</span>
                  )}
                </Field>
                <Field label="Current task">
                  {ticket ? (
                    <span>
                      <span className="font-mono text-[11px] text-muted">{ticket.code}</span> {ticket.title}
                    </span>
                  ) : isOrch && a.status === "WAITING_APPROVAL" ? (
                    <span>Awaiting human launch decision</span>
                  ) : (
                    <span className="text-faint">None</span>
                  )}
                </Field>
                <Field label="Last run">{a.lastRunAt ? formatRelative(a.lastRunAt) : <span className="text-faint">not recorded</span>}</Field>
                <Field label="Outputs produced">
                  <span className="num font-medium">{a.outputsProduced}</span>
                </Field>
                <div className={cn("col-span-2", isOrch && "md:col-span-4")}>
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-muted">Responsibilities</div>
                  <ul className="mt-1 flex flex-wrap gap-1">
                    {a.responsibilities.map((r) => (
                      <li key={r} className="rounded-sm border bg-canvas px-1.5 py-0.5 text-[11px] text-ink-2">
                        {r}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      <p className="mt-4 flex items-center gap-1.5 text-[11px] text-muted">
        <Bot className="size-3.5" /> Agent codes: ORCH, 01–06. Real runs arrive through the AI Orchestrator seam (see Settings).
      </p>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-[10px] font-semibold uppercase tracking-wider text-muted">{label}</div>
      <div className="mt-0.5 text-[13px] text-ink">{children}</div>
    </div>
  );
}
