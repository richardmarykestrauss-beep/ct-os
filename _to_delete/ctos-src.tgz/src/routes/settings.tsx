import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, SectionTitle } from "@/components/os/PageHeader";
import { SafetyPipeline } from "@/components/os/Pipeline";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { INTEGRATIONS } from "@/services/integrations";
import { PERMISSION_MODEL } from "@/data/state-machine";
import { useOS } from "@/state/os-store";
import { cn } from "@/lib/utils";
import { Database, Plug, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

const TIER_CLS = {
  GREEN: "border-ok/40 bg-ok-soft text-ok",
  AMBER: "border-warn/40 bg-warn-soft text-warn",
  RED: "border-danger/40 bg-danger-soft text-danger",
};

function SettingsPage() {
  const { repositoryKind } = useOS();
  return (
    <>
      <PageHeader title="Settings" subtitle="Integrations, safety doctrine and permission model. Nothing here is connected yet." />

      <Card className="mb-5">
        <CardContent className="grid gap-3 md:grid-cols-2">
          <div className="rounded-md border bg-canvas px-3 py-2.5">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted">
              <Database className="size-3.5" /> Control plane
            </div>
            <p className="mt-1 text-xs text-ink-2">This dashboard. It records project state, tickets, approvals and holds. It never executes changes on a client site itself.</p>
            <div className="mt-2 text-[11px] text-muted">
              Store: <Badge tone="outline">{repositoryKind === "memory" ? "In-memory (session only)" : repositoryKind}</Badge>
            </div>
          </div>
          <div className="rounded-md border bg-canvas px-3 py-2.5">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted">
              <Plug className="size-3.5" /> Execution plane
            </div>
            <p className="mt-1 text-xs text-ink-2">Agents and external systems (WordPress, Cloudflare, Google, Meta, hosting) do the actual work, under the permission model below. Connected via adapters later.</p>
          </div>
        </CardContent>
      </Card>

      <SectionTitle>Integrations</SectionTitle>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        {INTEGRATIONS.map((i) => (
          <Card key={i.id} className="px-4 py-3">
            <div className="flex items-start justify-between gap-2">
              <div className="text-[13px] font-semibold text-ink">{i.name}</div>
              <Badge tone="neutral">
                <span className="size-1.5 rounded-full bg-faint" />
                {i.status === "NOT_CONNECTED" ? "Not Connected" : "Future Integration"}
              </Badge>
            </div>
            <div className="mt-1 text-xs text-muted">{i.purpose}</div>
            <div className="mt-2 text-[10px] uppercase tracking-wider text-faint">{i.plane} plane</div>
          </Card>
        ))}
      </div>

      <SectionTitle className="mt-6">Global safety doctrine</SectionTitle>
      <Card>
        <CardContent>
          <SafetyPipeline />
          <p className="mt-2 text-xs text-muted">Every build passes through two human gates. QA at zero is necessary, never sufficient, for launch.</p>
        </CardContent>
      </Card>

      <SectionTitle className="mt-6">Permission model (future enforcement)</SectionTitle>
      <div className="grid gap-3 md:grid-cols-3">
        {PERMISSION_MODEL.map((tier) => (
          <Card key={tier.tier} className={cn("border-2", tier.tier === "GREEN" ? "border-ok/30" : tier.tier === "AMBER" ? "border-warn/30" : "border-danger/30")}>
            <CardHeader>
              <div>
                <CardTitle className="flex items-center gap-2">
                  <span className={cn("rounded-sm border px-1.5 py-0.5 font-mono text-[10px] font-bold", TIER_CLS[tier.tier])}>{tier.tier}</span>
                  {tier.label}
                </CardTitle>
                <p className="mt-0.5 text-xs text-muted">{tier.rule}</p>
              </div>
              <ShieldCheck className="size-4 text-faint" />
            </CardHeader>
            <CardContent>
              <ul className="grid gap-1">
                {tier.actions.map((a) => (
                  <li key={a} className="rounded-sm bg-canvas px-2 py-1 text-xs text-ink-2">
                    {a}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  );
}
